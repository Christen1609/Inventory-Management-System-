// function validate(path)
// {
//     var username=document.getElementById("username").value;
//     var password=document.getElementById("password").value;
//     var Sbutton=document.lastElementChild.firstElementChild.lastElementChild;
//     if(username=="admin" && password=="user")
//     {
//        // Sbutton.innerHTML = "<a href='https://www.w3schools.com'></a>"
//         alert("Login Succesfull");
//         // window.location.href= stats.html';
//         // return false;
//     }
//     else
//     {
//         alert("Login Failed");
//     }
// }
