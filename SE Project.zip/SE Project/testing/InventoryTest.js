var functions ={
    add : (num1,num2) => num1+num2,
  
    createuser: () =>{
 const user= { name : 'Vijayaditya'};
 return user;
    }

};
module.exports = functions;